package net.hudup.logistic.math;


/**
 * 
 * @author Loc Nguyen
 * @version 10.0
 *
 */
public class TransferKey {
	
	
	/**
	 * 
	 * @return tramsfer key
	 */
	protected byte[] transfer() {
		return new byte[] 
				{ 's', 't', 'b', 'q', 't', 'k', '6', '1', 'm', 'q', 'e','u', 'x', 'i', 'o', 'k' };
	}
	
	
}
